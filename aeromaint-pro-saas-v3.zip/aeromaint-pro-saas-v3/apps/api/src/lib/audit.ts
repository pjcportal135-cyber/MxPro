import { pool } from './db';

export async function writeAuditLog(params: {
  organizationId?: string | null;
  userId?: string | null;
  entityType: string;
  entityId?: string | null;
  action: string;
  details?: Record<string, unknown>;
}) {
  await pool.query(
    `INSERT INTO audit_logs (organization_id, user_id, entity_type, entity_id, action, details)
     VALUES ($1, $2, $3, $4, $5, $6)`,
    [
      params.organizationId ?? null,
      params.userId ?? null,
      params.entityType,
      params.entityId ?? null,
      params.action,
      JSON.stringify(params.details ?? {}),
    ],
  );
}
