import { Router } from 'express';
import { z } from 'zod';
import { pool } from '../lib/db';
import { writeAuditLog } from '../lib/audit';
import type { AuthRequest } from '../middleware/auth';

const router = Router();

router.get('/', async (req: AuthRequest, res) => {
  const result = await pool.query('SELECT * FROM signatures WHERE organization_id = $1 ORDER BY signed_at DESC', [req.user!.organizationId]);
  res.json(result.rows);
});

router.post('/', async (req: AuthRequest, res) => {
  const schema = z.object({
    technicianId: z.string().uuid().optional(),
    signatureType: z.enum(['technician_signoff','inspection_signoff','release_to_service']),
    signedName: z.string().min(2),
    certificateNumber: z.string().optional(),
    signatureHash: z.string().optional(),
    metadata: z.record(z.any()).optional(),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Invalid payload' });

  const result = await pool.query(
    `INSERT INTO signatures (organization_id, technician_id, signed_by_user_id, signature_type, signed_name, certificate_number, signature_hash, metadata)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
    [
      req.user!.organizationId,
      parsed.data.technicianId ?? null,
      req.user!.userId,
      parsed.data.signatureType,
      parsed.data.signedName,
      parsed.data.certificateNumber ?? null,
      parsed.data.signatureHash ?? null,
      JSON.stringify(parsed.data.metadata ?? {}),
    ],
  );

  await writeAuditLog({ organizationId: req.user!.organizationId, userId: req.user!.userId, entityType: 'signature', entityId: result.rows[0].id, action: 'create', details: { type: parsed.data.signatureType, signedName: parsed.data.signedName } });
  res.status(201).json(result.rows[0]);
});

export default router;
