import { Router } from 'express';
import { z } from 'zod';
import { pool } from '../lib/db';
import { writeAuditLog } from '../lib/audit';
import type { AuthRequest } from '../middleware/auth';

const router = Router();

router.get('/', async (req: AuthRequest, res) => {
  const result = await pool.query(
    `SELECT rr.*, a.registration, wo.work_order_number, s.signed_name
     FROM release_records rr
     JOIN aircraft a ON a.id = rr.aircraft_id
     LEFT JOIN work_orders wo ON wo.id = rr.work_order_id
     LEFT JOIN signatures s ON s.id = rr.released_by_signature_id
     WHERE rr.organization_id = $1
     ORDER BY rr.released_at DESC`,
    [req.user!.organizationId],
  );
  res.json(result.rows);
});

router.post('/', async (req: AuthRequest, res) => {
  const schema = z.object({
    aircraftId: z.string().uuid(),
    workOrderId: z.string().uuid().optional(),
    maintenanceLogId: z.string().uuid().optional(),
    statement: z.string().min(10),
    releasedBySignatureId: z.string().uuid(),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Invalid payload' });

  const result = await pool.query(
    `INSERT INTO release_records (organization_id, aircraft_id, work_order_id, maintenance_log_id, statement, released_by_signature_id)
     VALUES ($1,$2,$3,$4,$5,$6) RETURNING *`,
    [
      req.user!.organizationId,
      parsed.data.aircraftId,
      parsed.data.workOrderId ?? null,
      parsed.data.maintenanceLogId ?? null,
      parsed.data.statement,
      parsed.data.releasedBySignatureId,
    ],
  );

  await pool.query(
    `UPDATE work_orders SET status = 'released', updated_at = NOW()
     WHERE id = $1 AND organization_id = $2`,
    [parsed.data.workOrderId ?? null, req.user!.organizationId],
  );

  await writeAuditLog({ organizationId: req.user!.organizationId, userId: req.user!.userId, entityType: 'release_record', entityId: result.rows[0].id, action: 'create', details: { aircraftId: parsed.data.aircraftId, workOrderId: parsed.data.workOrderId ?? null } });
  res.status(201).json(result.rows[0]);
});

export default router;
