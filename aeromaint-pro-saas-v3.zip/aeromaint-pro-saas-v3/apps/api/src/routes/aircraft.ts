import { Router } from 'express';
import { z } from 'zod';
import { pool } from '../lib/db';
import { writeAuditLog } from '../lib/audit';
import type { AuthRequest } from '../middleware/auth';

const router = Router();

router.get('/', async (req: AuthRequest, res) => {
  const result = await pool.query('SELECT * FROM aircraft WHERE organization_id = $1 ORDER BY registration', [req.user!.organizationId]);
  res.json(result.rows);
});

router.post('/', async (req: AuthRequest, res) => {
  const schema = z.object({
    registration: z.string().min(2),
    manufacturer: z.string().min(2),
    model: z.string().min(1),
    serialNumber: z.string().optional(),
    status: z.enum(['in_service', 'maintenance', 'aog']).default('in_service'),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Invalid payload' });

  const result = await pool.query(
    `INSERT INTO aircraft (organization_id, registration, manufacturer, model, serial_number, status)
     VALUES ($1,$2,$3,$4,$5,$6) RETURNING *`,
    [
      req.user!.organizationId,
      parsed.data.registration,
      parsed.data.manufacturer,
      parsed.data.model,
      parsed.data.serialNumber ?? null,
      parsed.data.status,
    ],
  );

  await writeAuditLog({
    organizationId: req.user!.organizationId,
    userId: req.user!.userId,
    entityType: 'aircraft',
    entityId: result.rows[0].id,
    action: 'create',
    details: { registration: parsed.data.registration },
  });

  res.status(201).json(result.rows[0]);
});

export default router;
