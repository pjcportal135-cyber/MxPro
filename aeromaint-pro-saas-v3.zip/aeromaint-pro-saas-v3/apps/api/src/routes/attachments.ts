import { Router } from 'express';
import { z } from 'zod';
import { pool } from '../lib/db';
import { writeAuditLog } from '../lib/audit';
import type { AuthRequest } from '../middleware/auth';

const router = Router();

router.get('/', async (req: AuthRequest, res) => {
  const entityType = req.query.entityType as string | undefined;
  const entityId = req.query.entityId as string | undefined;
  const result = await pool.query(
    `SELECT * FROM attachments
     WHERE organization_id = $1
       AND ($2::text IS NULL OR entity_type = $2)
       AND ($3::uuid IS NULL OR entity_id = $3)
     ORDER BY created_at DESC`,
    [req.user!.organizationId, entityType ?? null, entityId ?? null],
  );
  res.json(result.rows);
});

router.post('/', async (req: AuthRequest, res) => {
  const schema = z.object({
    entityType: z.enum(['aircraft','work_order','inspection','maintenance_log','squawk','release_record']),
    entityId: z.string().uuid(),
    fileName: z.string().min(1),
    storageKey: z.string().min(1),
    mimeType: z.string().optional(),
    fileSizeBytes: z.number().int().nonnegative().optional(),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Invalid payload' });

  const result = await pool.query(
    `INSERT INTO attachments (organization_id, entity_type, entity_id, file_name, storage_key, mime_type, file_size_bytes, uploaded_by_user_id)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
    [
      req.user!.organizationId,
      parsed.data.entityType,
      parsed.data.entityId,
      parsed.data.fileName,
      parsed.data.storageKey,
      parsed.data.mimeType ?? null,
      parsed.data.fileSizeBytes ?? null,
      req.user!.userId,
    ],
  );

  await writeAuditLog({ organizationId: req.user!.organizationId, userId: req.user!.userId, entityType: 'attachment', entityId: result.rows[0].id, action: 'create', details: parsed.data });
  res.status(201).json(result.rows[0]);
});

export default router;
