import { Router } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { z } from 'zod';
import { pool } from '../lib/db';

const router = Router();

router.post('/login', async (req, res) => {
  const schema = z.object({ email: z.string().email(), password: z.string().min(8) });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Invalid input' });

  const userResult = await pool.query(
    `SELECT u.id, u.email, u.password_hash, ou.organization_id, ou.role
     FROM users u
     JOIN organization_users ou ON ou.user_id = u.id
     WHERE lower(u.email) = lower($1)
     LIMIT 1`,
    [parsed.data.email],
  );

  const user = userResult.rows[0];
  if (!user) return res.status(401).json({ error: 'Invalid credentials' });

  const ok = await bcrypt.compare(parsed.data.password, user.password_hash);
  if (!ok) return res.status(401).json({ error: 'Invalid credentials' });

  const token = jwt.sign(
    { userId: user.id, organizationId: user.organization_id, role: user.role },
    process.env.JWT_SECRET || 'change-me',
    { expiresIn: '12h' },
  );

  res.json({ token, user: { email: user.email, role: user.role, organizationId: user.organization_id } });
});

export default router;
