import { Router } from 'express';
import { z } from 'zod';
import { pool } from '../lib/db';
import { writeAuditLog } from '../lib/audit';
import type { AuthRequest } from '../middleware/auth';

const router = Router();

router.get('/', async (req: AuthRequest, res) => {
  const result = await pool.query(
    `SELECT wo.*, a.registration, t.full_name AS technician_name
     FROM work_orders wo
     JOIN aircraft a ON a.id = wo.aircraft_id
     LEFT JOIN technicians t ON t.id = wo.assigned_technician_id
     WHERE wo.organization_id = $1
     ORDER BY wo.created_at DESC`,
    [req.user!.organizationId],
  );
  res.json(result.rows);
});

router.patch('/:id', async (req: AuthRequest, res) => {
  const schema = z.object({
    status: z.enum(['open','in_progress','waiting_parts','completed','released']).optional(),
    priority: z.enum(['routine','urgent','mel']).optional(),
    title: z.string().min(2).optional(),
    description: z.string().optional(),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Invalid payload' });

  const fields: string[] = [];
  const values: unknown[] = [];
  let idx = 1;
  for (const [key, value] of Object.entries(parsed.data)) {
    fields.push(`${key === 'assignedTechnicianId' ? 'assigned_technician_id' : key} = $${idx++}`);
    values.push(value);
  }
  fields.push(`updated_at = NOW()`);
  values.push(req.params.id, req.user!.organizationId);

  const result = await pool.query(
    `UPDATE work_orders SET ${fields.join(', ')} WHERE id = $${idx++} AND organization_id = $${idx} RETURNING *`,
    values,
  );
  if (!result.rows[0]) return res.status(404).json({ error: 'Work order not found' });

  await writeAuditLog({ organizationId: req.user!.organizationId, userId: req.user!.userId, entityType: 'work_order', entityId: req.params.id, action: 'update', details: parsed.data });
  res.json(result.rows[0]);
});

export default router;
