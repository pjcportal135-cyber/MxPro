import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import authRoutes from './routes/auth';
import aircraftRoutes from './routes/aircraft';
import workOrderRoutes from './routes/work-orders';
import attachmentRoutes from './routes/attachments';
import signatureRoutes from './routes/signatures';
import releaseRoutes from './routes/releases';
import { requireAuth } from './middleware/auth';

const app = express();
app.use(cors());
app.use(express.json());

app.get('/health', (_req, res) => res.json({ ok: true }));
app.use('/auth', authRoutes);
app.use('/aircraft', requireAuth, aircraftRoutes);
app.use('/work-orders', requireAuth, workOrderRoutes);
app.use('/attachments', requireAuth, attachmentRoutes);
app.use('/signatures', requireAuth, signatureRoutes);
app.use('/releases', requireAuth, releaseRoutes);

const port = Number(process.env.PORT || 4000);
app.listen(port, () => {
  console.log(`API listening on ${port}`);
});
