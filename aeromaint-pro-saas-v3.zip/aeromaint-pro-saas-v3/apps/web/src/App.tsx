import { FormEvent, useMemo, useState } from 'react';
import DashboardPage from './pages/DashboardPage';
import { API_URL } from './lib/api';

export default function App() {
  const [token, setToken] = useState<string | null>(() => localStorage.getItem('token'));
  const [email, setEmail] = useState('admin@skybridge.aero');
  const [password, setPassword] = useState('ChangeMe123!');
  const [error, setError] = useState('');

  const loggedIn = useMemo(() => Boolean(token), [token]);

  async function handleLogin(e: FormEvent) {
    e.preventDefault();
    setError('');
    try {
      const response = await fetch(`${API_URL}/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Login failed');
      localStorage.setItem('token', data.token);
      setToken(data.token);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Login failed');
    }
  }

  if (!loggedIn) {
    return (
      <div style={{ minHeight: '100vh', background: '#f3f4f6', display: 'grid', placeItems: 'center', padding: 24 }}>
        <form onSubmit={handleLogin} style={{ width: '100%', maxWidth: 420, background: '#fff', padding: 24, borderRadius: 16, border: '1px solid #e5e7eb' }}>
          <h1>AeroMaint Pro SaaS</h1>
          <p>Phase 3 aviation maintenance platform starter.</p>
          <input value={email} onChange={e => setEmail(e.target.value)} placeholder="Email" style={{ width: '100%', marginBottom: 12, padding: 12 }} />
          <input value={password} onChange={e => setPassword(e.target.value)} type="password" placeholder="Password" style={{ width: '100%', marginBottom: 12, padding: 12 }} />
          {error ? <div style={{ color: 'crimson', marginBottom: 12 }}>{error}</div> : null}
          <button type="submit" style={{ width: '100%', padding: 12 }}>Login</button>
        </form>
      </div>
    );
  }

  return (
    <div style={{ minHeight: '100vh', background: '#f3f4f6', padding: 24 }}>
      <div style={{ maxWidth: 1100, margin: '0 auto', display: 'grid', gap: 16 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <h1 style={{ marginBottom: 4 }}>AeroMaint Pro</h1>
            <div>Attachments, signatures, and release-to-service foundation</div>
          </div>
          <button onClick={() => { localStorage.removeItem('token'); setToken(null); }}>Logout</button>
        </div>
        <DashboardPage />
      </div>
    </div>
  );
}
