import { useEffect, useState } from 'react';
import Card from '../components/Card';
import { apiFetch } from '../lib/api';

type Aircraft = { id: string; registration: string; manufacturer: string; model: string; status: string };
type WorkOrder = { id: string; work_order_number: string; title: string; status: string; registration: string };
type Attachment = { id: string; file_name: string; entity_type: string; created_at: string };
type Signature = { id: string; signed_name: string; signature_type: string; signed_at: string };
type Release = { id: string; registration: string; work_order_number: string | null; signed_name: string | null; released_at: string };

export default function DashboardPage() {
  const [aircraft, setAircraft] = useState<Aircraft[]>([]);
  const [workOrders, setWorkOrders] = useState<WorkOrder[]>([]);
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [signatures, setSignatures] = useState<Signature[]>([]);
  const [releases, setReleases] = useState<Release[]>([]);

  useEffect(() => {
    Promise.all([
      apiFetch('/aircraft'),
      apiFetch('/work-orders'),
      apiFetch('/attachments'),
      apiFetch('/signatures'),
      apiFetch('/releases'),
    ]).then(([a, w, at, s, r]) => {
      setAircraft(a);
      setWorkOrders(w);
      setAttachments(at);
      setSignatures(s);
      setReleases(r);
    }).catch(console.error);
  }, []);

  return (
    <div style={{ display: 'grid', gap: 16 }}>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: 16 }}>
        <Card><strong>Aircraft</strong><div>{aircraft.length}</div></Card>
        <Card><strong>Open Work Orders</strong><div>{workOrders.filter(w => w.status !== 'released').length}</div></Card>
        <Card><strong>Attachments</strong><div>{attachments.length}</div></Card>
        <Card><strong>Signatures</strong><div>{signatures.length}</div></Card>
      </div>

      <Card>
        <h3>Fleet</h3>
        {aircraft.map(item => <div key={item.id}>{item.registration} — {item.manufacturer} {item.model} — {item.status}</div>)}
      </Card>

      <Card>
        <h3>Recent Attachments</h3>
        {attachments.slice(0, 5).map(item => <div key={item.id}>{item.file_name} — {item.entity_type}</div>)}
      </Card>

      <Card>
        <h3>Recent Technician Signatures</h3>
        {signatures.slice(0, 5).map(item => <div key={item.id}>{item.signed_name} — {item.signature_type}</div>)}
      </Card>

      <Card>
        <h3>Release to Service</h3>
        {releases.slice(0, 5).map(item => <div key={item.id}>{item.registration} — {item.work_order_number ?? 'No WO'} — {item.signed_name ?? 'Unsigned'}</div>)}
      </Card>
    </div>
  );
}
