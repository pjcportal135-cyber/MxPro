# iPad deploy notes

## Best workflow from iPad
1. Upload this project to GitHub.
2. Use a VPS or cloud host for API and database.
3. Use Termius on iPad for SSH.
4. Use Safari to test the frontend.

## Minimum VPS commands
```bash
sudo apt update
sudo apt install -y nodejs npm git postgresql
```

## API on VPS
```bash
cd apps/api
cp .env.example .env
npm install
npm run dev
```

## Web on VPS
```bash
cd apps/web
cp .env.example .env
npm install
npm run dev -- --host 0.0.0.0
```

## Production direction
- Put the API behind Nginx
- Put the web app on Vercel or Nginx
- Store attachments in S3 or Cloudflare R2
- Add HTTPS before inviting users
