INSERT INTO organizations (id, name, slug)
VALUES ('11111111-1111-1111-1111-111111111111', 'SkyBridge Aviation', 'skybridge')
ON CONFLICT (slug) DO NOTHING;

INSERT INTO users (id, email, password_hash, full_name)
VALUES (
  '22222222-2222-2222-2222-222222222222',
  'admin@skybridge.aero',
  '$2a$10$drT5Q6XQnA5H9N6nNSh2UeX30AFl3h5TADaBrZEcD3xKhsR4HIX66',
  'SkyBridge Admin'
)
ON CONFLICT (email) DO NOTHING;

INSERT INTO organization_users (organization_id, user_id, role)
VALUES ('11111111-1111-1111-1111-111111111111','22222222-2222-2222-2222-222222222222','company_admin')
ON CONFLICT DO NOTHING;

INSERT INTO technicians (id, organization_id, full_name, certificate_number, certificate_type)
VALUES ('33333333-3333-3333-3333-333333333333','11111111-1111-1111-1111-111111111111','Chris Turner','A&P-774211','A&P')
ON CONFLICT DO NOTHING;

INSERT INTO aircraft (id, organization_id, registration, manufacturer, model, serial_number, status)
VALUES ('44444444-4444-4444-4444-444444444444','11111111-1111-1111-1111-111111111111','N651CV','Cessna','Citation VII','CIT-7001','in_service')
ON CONFLICT DO NOTHING;

INSERT INTO work_orders (id, organization_id, aircraft_id, work_order_number, title, description, status, priority, assigned_technician_id)
VALUES ('55555555-5555-5555-5555-555555555555','11111111-1111-1111-1111-111111111111','44444444-4444-4444-4444-444444444444','WO-1001','Left landing light replacement','Replace inoperative left landing light','completed','urgent','33333333-3333-3333-3333-333333333333')
ON CONFLICT DO NOTHING;

INSERT INTO signatures (id, organization_id, technician_id, signed_by_user_id, signature_type, signed_name, certificate_number, signature_hash)
VALUES ('66666666-6666-6666-6666-666666666666','11111111-1111-1111-1111-111111111111','33333333-3333-3333-3333-333333333333','22222222-2222-2222-2222-222222222222','release_to_service','Chris Turner','A&P-774211','demo-hash-001')
ON CONFLICT DO NOTHING;

INSERT INTO attachments (id, organization_id, entity_type, entity_id, file_name, storage_key, mime_type, uploaded_by_user_id)
VALUES ('77777777-7777-7777-7777-777777777777','11111111-1111-1111-1111-111111111111','work_order','55555555-5555-5555-5555-555555555555','wo-1001-photo.jpg','demo/wo-1001-photo.jpg','image/jpeg','22222222-2222-2222-2222-222222222222')
ON CONFLICT DO NOTHING;

INSERT INTO release_records (id, organization_id, aircraft_id, work_order_id, statement, released_by_signature_id)
VALUES ('88888888-8888-8888-8888-888888888888','11111111-1111-1111-1111-111111111111','44444444-4444-4444-4444-444444444444','55555555-5555-5555-5555-555555555555','Aircraft inspected and returned to service in an airworthy condition.','66666666-6666-6666-6666-666666666666')
ON CONFLICT DO NOTHING;
