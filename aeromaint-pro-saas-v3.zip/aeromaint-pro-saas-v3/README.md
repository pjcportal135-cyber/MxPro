# AeroMaint Pro SaaS v3

Phase 3 starter for a multi-tenant aviation maintenance SaaS.

## What's new in v3
- Attachments module metadata
- Technician e-signatures
- Release-to-service records
- Edit/update API routes
- Audit log middleware hooks
- iPad-friendly deploy notes

## Stack
- Frontend: React + TypeScript + Vite
- Backend: Node.js + Express + TypeScript
- Database: PostgreSQL
- Auth: JWT
- Storage: attachment metadata table ready for S3 / Cloudflare R2

## Project structure
- `apps/api` backend API
- `apps/web` frontend app
- `database/schema.sql` full schema
- `docs/ipad-deploy.md` iPad workflow

## Quick start
### 1. Database
Create a PostgreSQL database and run:

```sql
\i database/schema.sql
```

### 2. API
```bash
cd apps/api
cp .env.example .env
npm install
npm run dev
```

### 3. Web
```bash
cd apps/web
cp .env.example .env
npm install
npm run dev
```

## Demo login
After loading your own seed/demo data, use:
- `admin@skybridge.aero`
- `ChangeMe123!`

## Important
This is a strong SaaS foundation and not yet a production-certified aviation records system.
Before real-world use, add:
- hardened auth and password reset flow
- object storage uploads
- immutable signature storage
- full audit/event trail coverage
- testing
- backups
- tenancy enforcement review
- compliance/legal review for aviation use
