import { ReactNode } from 'react';

export function Card({ title, children }: { title?: string; children: ReactNode }) {
  return (
    <div className="rounded-2xl border border-slate-800 bg-slate-900/70 p-5 shadow-xl shadow-slate-950/20">
      {title ? <h3 className="mb-4 text-sm font-semibold uppercase tracking-wide text-slate-400">{title}</h3> : null}
      {children}
    </div>
  );
}
