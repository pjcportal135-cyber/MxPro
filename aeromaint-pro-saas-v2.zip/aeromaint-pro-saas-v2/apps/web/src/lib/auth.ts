export type Session = {
  token: string;
  user: {
    id: string;
    fullName: string;
    email: string;
    role: string;
  };
  organization: {
    id: string;
    name: string;
    slug: string;
    plan: string;
  };
};

const KEY = 'aeromaint_session';
const TOKEN_KEY = 'aeromaint_token';

export function saveSession(session: Session) {
  localStorage.setItem(KEY, JSON.stringify(session));
  localStorage.setItem(TOKEN_KEY, session.token);
}

export function getSession(): Session | null {
  const raw = localStorage.getItem(KEY);
  if (!raw) return null;
  try {
    return JSON.parse(raw) as Session;
  } catch {
    return null;
  }
}

export function clearSession() {
  localStorage.removeItem(KEY);
  localStorage.removeItem(TOKEN_KEY);
}
