export function LandingPage({ onShowLogin }: { onShowLogin: () => void }) {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100">
      <div className="mx-auto max-w-6xl px-6 py-12">
        <header className="flex items-center justify-between">
          <div>
            <div className="text-2xl font-bold">AeroMaint Pro</div>
            <div className="text-sm text-slate-400">Multi-tenant aviation maintenance SaaS</div>
          </div>
          <button
            className="rounded-xl bg-sky-500 px-4 py-2 font-medium text-slate-950 transition hover:bg-sky-400"
            onClick={onShowLogin}
          >
            Sign in
          </button>
        </header>

        <main className="grid gap-10 py-16 lg:grid-cols-2 lg:items-center">
          <div>
            <div className="inline-flex rounded-full border border-sky-800 bg-sky-950/60 px-3 py-1 text-xs text-sky-300">
              Built for operators, MRO teams, and growing fleets
            </div>
            <h1 className="mt-6 text-5xl font-bold tracking-tight text-white">
              Your own aviation maintenance SaaS, not locked inside Replit.
            </h1>
            <p className="mt-6 max-w-xl text-lg text-slate-300">
              Manage aircraft, organizations, users, and maintenance records in a platform you own and can deploy anywhere.
            </p>
            <div className="mt-8 flex gap-3">
              <button className="rounded-xl bg-sky-500 px-5 py-3 font-medium text-slate-950" onClick={onShowLogin}>
                Start demo
              </button>
              <a
                className="rounded-xl border border-slate-700 px-5 py-3 font-medium text-slate-200"
                href="#features"
              >
                View features
              </a>
            </div>
          </div>

          <div className="rounded-3xl border border-slate-800 bg-slate-900 p-6 shadow-2xl shadow-slate-950/40">
            <div className="grid gap-4 sm:grid-cols-2">
              {[
                'Multi-tenant organizations',
                'Role-based access',
                'Aircraft dashboard starter',
                'JWT auth and onboarding',
                'Audit-ready data model',
                'Billing-ready SaaS foundation',
              ].map((item) => (
                <div key={item} className="rounded-2xl border border-slate-800 bg-slate-950 p-4 text-sm text-slate-300">
                  {item}
                </div>
              ))}
            </div>
          </div>
        </main>

        <section id="features" className="grid gap-6 pb-12 md:grid-cols-3">
          {[
            ['Organizations', 'Every customer has isolated fleet data and users.'],
            ['Aircraft', 'Tail numbers, hours, cycles, status, and location.'],
            ['Foundation', 'Ready for forms, signatures, and forecast logic.'],
          ].map(([title, text]) => (
            <div key={title} className="rounded-2xl border border-slate-800 bg-slate-900 p-5">
              <h3 className="text-lg font-semibold text-white">{title}</h3>
              <p className="mt-2 text-sm text-slate-400">{text}</p>
            </div>
          ))}
        </section>
      </div>
    </div>
  );
}
