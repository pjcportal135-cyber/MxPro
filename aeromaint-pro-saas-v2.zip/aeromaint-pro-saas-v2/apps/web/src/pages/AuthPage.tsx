import { FormEvent, useState } from 'react';
import { api } from '../lib/api';
import { saveSession, Session } from '../lib/auth';

type Mode = 'login' | 'register';

export function AuthPage({ onSignedIn }: { onSignedIn: (session: Session) => void }) {
  const [mode, setMode] = useState<Mode>('login');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError(null);
    setLoading(true);

    const form = new FormData(event.currentTarget);

    try {
      const payload =
        mode === 'login'
          ? {
              email: String(form.get('email') || ''),
              password: String(form.get('password') || ''),
            }
          : {
              organizationName: String(form.get('organizationName') || ''),
              fullName: String(form.get('fullName') || ''),
              email: String(form.get('email') || ''),
              password: String(form.get('password') || ''),
            };

      const session = await api<Session>(mode === 'login' ? '/auth/login' : '/auth/register', {
        method: 'POST',
        body: JSON.stringify(payload),
      });

      saveSession(session);
      onSignedIn(session);
    } catch (err: any) {
      setError(err.message || 'Could not sign in');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-slate-950 px-6 py-12 text-slate-100">
      <div className="mx-auto max-w-md rounded-3xl border border-slate-800 bg-slate-900 p-8 shadow-2xl shadow-slate-950/50">
        <div className="text-center">
          <h1 className="text-3xl font-bold text-white">{mode === 'login' ? 'Sign in' : 'Create organization'}</h1>
          <p className="mt-2 text-sm text-slate-400">
            {mode === 'login' ? 'Use the seeded demo account or your own organization login.' : 'Start your first operator account.'}
          </p>
        </div>

        <form className="mt-8 space-y-4" onSubmit={handleSubmit}>
          {mode === 'register' ? (
            <>
              <Field label="Organization name" name="organizationName" />
              <Field label="Your full name" name="fullName" />
            </>
          ) : null}
          <Field label="Email" name="email" type="email" defaultValue={mode === 'login' ? 'admin@skybridge.aero' : ''} />
          <Field label="Password" name="password" type="password" defaultValue={mode === 'login' ? 'ChangeMe123!' : ''} />

          {error ? <div className="rounded-xl border border-rose-900 bg-rose-950/40 px-4 py-3 text-sm text-rose-300">{error}</div> : null}

          <button
            disabled={loading}
            className="w-full rounded-xl bg-sky-500 px-4 py-3 font-semibold text-slate-950 transition hover:bg-sky-400 disabled:opacity-60"
          >
            {loading ? 'Please wait...' : mode === 'login' ? 'Sign in' : 'Create account'}
          </button>
        </form>

        <button
          className="mt-5 w-full text-sm text-slate-400 underline-offset-4 hover:text-slate-200 hover:underline"
          onClick={() => setMode(mode === 'login' ? 'register' : 'login')}
        >
          {mode === 'login' ? 'Need a new organization? Create one.' : 'Already have an account? Sign in.'}
        </button>
      </div>
    </div>
  );
}

function Field({ label, name, type = 'text', defaultValue = '' }: { label: string; name: string; type?: string; defaultValue?: string }) {
  return (
    <label className="block">
      <span className="mb-2 block text-sm text-slate-300">{label}</span>
      <input
        className="w-full rounded-xl border border-slate-700 bg-slate-950 px-4 py-3 text-slate-100 outline-none ring-0 placeholder:text-slate-600 focus:border-sky-500"
        name={name}
        type={type}
        defaultValue={defaultValue}
        required
      />
    </label>
  );
}
