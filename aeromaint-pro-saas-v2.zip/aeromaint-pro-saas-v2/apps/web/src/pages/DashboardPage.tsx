import { FormEvent, ReactNode, useEffect, useMemo, useState } from 'react';
import { api } from '../lib/api';
import { clearSession, Session } from '../lib/auth';
import { Card } from '../components/Card';
import { MetricCard } from '../components/MetricCard';

type DashboardData = {
  fleetCounts: { total_aircraft: number; in_service: number; maintenance: number; aog: number };
  opsCounts: { open_work_orders: number; open_squawks: number; overdue_inspections: number; due_soon_inspections: number };
  recentAircraft: Array<{ id: string; tail_number: string; manufacturer: string; model: string; status: string; total_hours: number; location: string | null }>;
  recentWorkOrders: Array<{ id: string; wo_number: string; tail_number: string; title: string; priority: string; status: string; created_at: string }>;
  recentAudit: Array<{ action: string; entity_type: string; created_at: string }>;
};

type Aircraft = {
  id: string;
  tail_number: string;
  manufacturer: string;
  model: string;
  status: string;
  total_hours: number;
  location: string | null;
};

type Inspection = {
  id: string;
  tail_number: string;
  code: string;
  title: string;
  interval_type: string;
  interval_value: number;
  due_on: string | null;
  due_hours: number | null;
  due_cycles: number | null;
  status: string;
};

type Squawk = {
  id: string;
  tail_number: string;
  reported_by: string | null;
  title: string;
  priority: string;
  status: string;
  created_at: string;
};

type WorkOrder = {
  id: string;
  tail_number: string;
  wo_number: string;
  title: string;
  priority: string;
  status: string;
  assigned_to: string | null;
  due_on: string | null;
};

type Tab = 'overview' | 'aircraft' | 'inspections' | 'squawks' | 'workOrders';

export function DashboardPage({ session, onSignedOut }: { session: Session; onSignedOut: () => void }) {
  const [dashboard, setDashboard] = useState<DashboardData | null>(null);
  const [aircraft, setAircraft] = useState<Aircraft[]>([]);
  const [inspections, setInspections] = useState<Inspection[]>([]);
  const [squawks, setSquawks] = useState<Squawk[]>([]);
  const [workOrders, setWorkOrders] = useState<WorkOrder[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [tab, setTab] = useState<Tab>('overview');

  async function load() {
    try {
      const [dashboardData, aircraftData, inspectionsData, squawksData, workOrdersData] = await Promise.all([
        api<DashboardData>('/dashboard'),
        api<Aircraft[]>('/aircraft'),
        api<Inspection[]>('/inspections'),
        api<Squawk[]>('/squawks'),
        api<WorkOrder[]>('/work-orders'),
      ]);
      setDashboard(dashboardData);
      setAircraft(aircraftData);
      setInspections(inspectionsData);
      setSquawks(squawksData);
      setWorkOrders(workOrdersData);
      setError(null);
    } catch (err: any) {
      setError(err.message || 'Failed to load dashboard');
    }
  }

  useEffect(() => {
    load();
  }, []);

  const planLabel = useMemo(() => session.organization.plan.toUpperCase(), [session.organization.plan]);

  async function submitJson(path: string, payload: unknown, onDone?: () => void) {
    setBusy(true);
    try {
      await api(path, { method: 'POST', body: JSON.stringify(payload) });
      await load();
      onDone?.();
      setError(null);
    } catch (err: any) {
      setError(err.message || 'Request failed');
    } finally {
      setBusy(false);
    }
  }

  function signOut() {
    clearSession();
    onSignedOut();
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100">
      <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 sm:py-8">
        <div className="mb-6 flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <div className="text-sm uppercase tracking-[0.2em] text-sky-300">{session.organization.name}</div>
            <h1 className="mt-2 text-3xl font-bold text-white sm:text-4xl">AeroMaint Pro SaaS</h1>
            <p className="mt-2 text-slate-400">{session.user.fullName} · {session.user.role} · {planLabel} plan</p>
          </div>
          <div className="flex gap-3">
            <div className="rounded-xl border border-slate-800 bg-slate-900 px-4 py-3 text-sm text-slate-300">{session.organization.slug}</div>
            <button className="rounded-xl border border-slate-700 px-4 py-3 text-sm hover:bg-slate-900" onClick={signOut}>Sign out</button>
          </div>
        </div>

        {error ? <div className="mb-6 rounded-xl border border-rose-900 bg-rose-950/30 px-4 py-3 text-rose-300">{error}</div> : null}

        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <MetricCard label="Aircraft" value={dashboard?.fleetCounts.total_aircraft ?? 0} />
          <MetricCard label="Open work orders" value={dashboard?.opsCounts.open_work_orders ?? 0} />
          <MetricCard label="Open squawks" value={dashboard?.opsCounts.open_squawks ?? 0} />
          <MetricCard label="Overdue inspections" value={dashboard?.opsCounts.overdue_inspections ?? 0} />
        </div>

        <div className="mt-6 flex flex-wrap gap-2">
          {[
            ['overview', 'Overview'],
            ['aircraft', 'Aircraft'],
            ['inspections', 'Inspections'],
            ['squawks', 'Squawks'],
            ['workOrders', 'Work Orders'],
          ].map(([value, label]) => (
            <button
              key={value}
              onClick={() => setTab(value as Tab)}
              className={`rounded-xl px-4 py-2 text-sm ${tab === value ? 'bg-sky-500 font-semibold text-slate-950' : 'border border-slate-700 text-slate-300 hover:bg-slate-900'}`}
            >
              {label}
            </button>
          ))}
        </div>

        {tab === 'overview' ? (
          <div className="mt-6 grid gap-6 xl:grid-cols-2">
            <Card title="Recent work orders">
              <div className="space-y-3">
                {dashboard?.recentWorkOrders.map((item) => (
                  <div key={item.id} className="rounded-xl border border-slate-800 bg-slate-950/60 px-4 py-3">
                    <div className="font-medium text-white">{item.wo_number} · {item.title}</div>
                    <div className="text-sm text-slate-400">{item.tail_number} · {item.priority} · {item.status}</div>
                  </div>
                ))}
              </div>
            </Card>
            <Card title="Recent activity">
              <div className="space-y-3">
                {dashboard?.recentAudit.map((item, index) => (
                  <div key={`${item.action}-${index}`} className="rounded-xl border border-slate-800 bg-slate-950/60 px-4 py-3">
                    <div className="text-sm font-medium text-white">{item.action} · {item.entity_type}</div>
                    <div className="mt-1 text-xs text-slate-400">{new Date(item.created_at).toLocaleString()}</div>
                  </div>
                ))}
              </div>
            </Card>
          </div>
        ) : null}

        {tab === 'aircraft' ? (
          <div className="mt-6 grid gap-6 xl:grid-cols-[1.5fr,1fr]">
            <Card title="Fleet">
              <SimpleTable
                headers={['Tail', 'Aircraft', 'Status', 'Hours', 'Location']}
                rows={aircraft.map((item) => [item.tail_number, `${item.manufacturer} ${item.model}`, item.status, String(item.total_hours), item.location || '—'])}
              />
            </Card>
            <Card title="Create aircraft">
              <FormAircraft busy={busy} onSubmit={(form) => submitJson('/aircraft', form, () => setTab('aircraft'))} />
            </Card>
          </div>
        ) : null}

        {tab === 'inspections' ? (
          <div className="mt-6 grid gap-6 xl:grid-cols-[1.5fr,1fr]">
            <Card title="Inspections">
              <SimpleTable
                headers={['Tail', 'Code', 'Title', 'Interval', 'Due', 'Status']}
                rows={inspections.map((item) => [
                  item.tail_number,
                  item.code,
                  item.title,
                  `${item.interval_value} ${item.interval_type}`,
                  item.due_on || (item.due_hours ? `${item.due_hours} hrs` : item.due_cycles ? `${item.due_cycles} cyc` : '—'),
                  item.status,
                ])}
              />
            </Card>
            <Card title="Create inspection">
              <FormInspection aircraft={aircraft} busy={busy} onSubmit={(form) => submitJson('/inspections', form, () => setTab('inspections'))} />
            </Card>
          </div>
        ) : null}

        {tab === 'squawks' ? (
          <div className="mt-6 grid gap-6 xl:grid-cols-[1.5fr,1fr]">
            <Card title="Squawks">
              <div className="space-y-3">
                {squawks.map((item) => (
                  <div key={item.id} className="rounded-xl border border-slate-800 bg-slate-950/60 px-4 py-3">
                    <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
                      <div>
                        <div className="font-medium text-white">{item.tail_number} · {item.title}</div>
                        <div className="text-sm text-slate-400">{item.priority} · {item.status} · {item.reported_by || 'Unknown reporter'}</div>
                      </div>
                      <button
                        className="rounded-lg border border-slate-700 px-3 py-2 text-xs hover:bg-slate-900"
                        onClick={() => submitJson(`/squawks/${item.id}/create-work-order`, {})}
                      >
                        Convert to work order
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
            <Card title="Create squawk">
              <FormSquawk aircraft={aircraft} busy={busy} onSubmit={(form) => submitJson('/squawks', form, () => setTab('squawks'))} />
            </Card>
          </div>
        ) : null}

        {tab === 'workOrders' ? (
          <div className="mt-6 grid gap-6 xl:grid-cols-[1.5fr,1fr]">
            <Card title="Work orders">
              <SimpleTable
                headers={['WO', 'Tail', 'Title', 'Priority', 'Status', 'Assigned']}
                rows={workOrders.map((item) => [item.wo_number, item.tail_number, item.title, item.priority, item.status, item.assigned_to || '—'])}
              />
            </Card>
            <Card title="Create work order">
              <FormWorkOrder aircraft={aircraft} busy={busy} onSubmit={(form) => submitJson('/work-orders', form, () => setTab('workOrders'))} />
            </Card>
          </div>
        ) : null}
      </div>
    </div>
  );
}

function SimpleTable({ headers, rows }: { headers: string[]; rows: string[][] }) {
  return (
    <div className="overflow-hidden rounded-2xl border border-slate-800">
      <table className="min-w-full divide-y divide-slate-800 text-left text-sm">
        <thead className="bg-slate-950/70 text-slate-400">
          <tr>{headers.map((header) => <th key={header} className="px-4 py-3">{header}</th>)}</tr>
        </thead>
        <tbody className="divide-y divide-slate-800 bg-slate-900/20">
          {rows.map((row, idx) => (
            <tr key={idx}>{row.map((cell, cellIdx) => <td key={cellIdx} className="px-4 py-3 text-slate-300">{cell}</td>)}</tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function FormAircraft({ busy, onSubmit }: { busy: boolean; onSubmit: (payload: Record<string, unknown>) => void }) {
  return (
    <EntityForm
      busy={busy}
      onSubmit={(e, form) => onSubmit({
        tailNumber: form.get('tailNumber'), serialNumber: form.get('serialNumber'), manufacturer: form.get('manufacturer'), model: form.get('model'),
        status: form.get('status'), totalHours: Number(form.get('totalHours') || 0), totalCycles: Number(form.get('totalCycles') || 0), landings: Number(form.get('landings') || 0),
        location: form.get('location'), notes: form.get('notes'),
      })}
      fields={<>
        <Input name="tailNumber" label="Tail number" />
        <Input name="serialNumber" label="Serial number" required={false} />
        <Input name="manufacturer" label="Manufacturer" />
        <Input name="model" label="Model" />
        <Select name="status" label="Status" options={[['in_service','In Service'],['maintenance','Maintenance'],['aog','AOG']]} />
        <Input name="location" label="Location" required={false} />
        <Input name="totalHours" label="Hours" type="number" />
        <Input name="totalCycles" label="Cycles" type="number" />
        <Input name="landings" label="Landings" type="number" />
        <TextArea name="notes" label="Notes" />
      </>}
      submitLabel="Add aircraft"
    />
  );
}

function FormInspection({ aircraft, busy, onSubmit }: { aircraft: Aircraft[]; busy: boolean; onSubmit: (payload: Record<string, unknown>) => void }) {
  return (
    <EntityForm
      busy={busy}
      onSubmit={(e, form) => onSubmit({
        aircraftId: form.get('aircraftId'), code: form.get('code'), title: form.get('title'), intervalType: form.get('intervalType'), intervalValue: Number(form.get('intervalValue') || 0),
        lastCompletedOn: form.get('lastCompletedOn'), dueOn: form.get('dueOn'), dueHours: form.get('dueHours') ? Number(form.get('dueHours')) : undefined,
        dueCycles: form.get('dueCycles') ? Number(form.get('dueCycles')) : undefined, status: form.get('status'), notes: form.get('notes'),
      })}
      fields={<>
        <Select name="aircraftId" label="Aircraft" options={aircraft.map((item) => [item.id, item.tail_number])} />
        <Input name="code" label="Code" />
        <Input name="title" label="Title" />
        <Select name="intervalType" label="Interval type" options={[['calendar','Calendar'],['hours','Hours'],['cycles','Cycles']]} />
        <Input name="intervalValue" label="Interval value" type="number" />
        <Input name="lastCompletedOn" label="Last completed" type="date" required={false} />
        <Input name="dueOn" label="Due date" type="date" required={false} />
        <Input name="dueHours" label="Due hours" type="number" required={false} />
        <Input name="dueCycles" label="Due cycles" type="number" required={false} />
        <Select name="status" label="Status" options={[['upcoming','Upcoming'],['due_soon','Due soon'],['overdue','Overdue'],['completed','Completed']]} />
        <TextArea name="notes" label="Notes" />
      </>}
      submitLabel="Add inspection"
    />
  );
}

function FormSquawk({ aircraft, busy, onSubmit }: { aircraft: Aircraft[]; busy: boolean; onSubmit: (payload: Record<string, unknown>) => void }) {
  return (
    <EntityForm
      busy={busy}
      onSubmit={(e, form) => onSubmit({
        aircraftId: form.get('aircraftId'), reportedBy: form.get('reportedBy'), title: form.get('title'), description: form.get('description'), priority: form.get('priority'), status: form.get('status'),
      })}
      fields={<>
        <Select name="aircraftId" label="Aircraft" options={aircraft.map((item) => [item.id, item.tail_number])} />
        <Input name="reportedBy" label="Reported by" required={false} />
        <Input name="title" label="Title" />
        <TextArea name="description" label="Description" />
        <Select name="priority" label="Priority" options={[['routine','Routine'],['priority','Priority'],['aog','AOG']]} />
        <Select name="status" label="Status" options={[['open','Open'],['in_progress','In progress'],['deferred','Deferred'],['closed','Closed']]} />
      </>}
      submitLabel="Add squawk"
    />
  );
}

function FormWorkOrder({ aircraft, busy, onSubmit }: { aircraft: Aircraft[]; busy: boolean; onSubmit: (payload: Record<string, unknown>) => void }) {
  return (
    <EntityForm
      busy={busy}
      onSubmit={(e, form) => onSubmit({
        aircraftId: form.get('aircraftId'), title: form.get('title'), description: form.get('description'), priority: form.get('priority'),
        status: form.get('status'), assignedTo: form.get('assignedTo'), dueOn: form.get('dueOn'),
      })}
      fields={<>
        <Select name="aircraftId" label="Aircraft" options={aircraft.map((item) => [item.id, item.tail_number])} />
        <Input name="title" label="Title" />
        <TextArea name="description" label="Description" />
        <Select name="priority" label="Priority" options={[['routine','Routine'],['priority','Priority'],['aog','AOG']]} />
        <Select name="status" label="Status" options={[['open','Open'],['in_progress','In progress'],['awaiting_parts','Awaiting parts'],['completed','Completed']]} />
        <Input name="assignedTo" label="Assigned to" required={false} />
        <Input name="dueOn" label="Due date" type="date" required={false} />
      </>}
      submitLabel="Add work order"
    />
  );
}

function EntityForm({ busy, fields, onSubmit, submitLabel }: { busy: boolean; fields: ReactNode; submitLabel: string; onSubmit: (event: FormEvent<HTMLFormElement>, form: FormData) => void }) {
  return (
    <form className="grid gap-3" onSubmit={(event) => { event.preventDefault(); const form = new FormData(event.currentTarget); onSubmit(event, form); event.currentTarget.reset(); }}>
      {fields}
      <button className="rounded-xl bg-sky-500 px-4 py-3 font-semibold text-slate-950 disabled:opacity-60" disabled={busy}>{busy ? 'Saving...' : submitLabel}</button>
    </form>
  );
}

function Input({ label, name, type = 'text', required = true }: { label: string; name: string; type?: string; required?: boolean }) {
  return <label><span className="mb-2 block text-sm text-slate-300">{label}</span><input name={name} type={type} required={required} className="w-full rounded-xl border border-slate-700 bg-slate-950 px-4 py-3 text-slate-100 focus:border-sky-500" /></label>;
}
function Select({ label, name, options }: { label: string; name: string; options: [string, string][] }) {
  return <label><span className="mb-2 block text-sm text-slate-300">{label}</span><select name={name} className="w-full rounded-xl border border-slate-700 bg-slate-950 px-4 py-3 text-slate-100 focus:border-sky-500">{options.map(([value, text]) => <option key={value} value={value}>{text}</option>)}</select></label>;
}
function TextArea({ label, name }: { label: string; name: string }) {
  return <label><span className="mb-2 block text-sm text-slate-300">{label}</span><textarea name={name} className="min-h-24 w-full rounded-xl border border-slate-700 bg-slate-950 px-4 py-3 text-slate-100 focus:border-sky-500" /></label>;
}
