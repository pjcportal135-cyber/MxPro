import { useState } from 'react';
import { getSession, Session } from './lib/auth';
import { LandingPage } from './pages/LandingPage';
import { AuthPage } from './pages/AuthPage';
import { DashboardPage } from './pages/DashboardPage';

type View = 'landing' | 'auth' | 'dashboard';

function App() {
  const existingSession = getSession();
  const [session, setSession] = useState<Session | null>(existingSession);
  const [view, setView] = useState<View>(existingSession ? 'dashboard' : 'landing');

  if (view === 'landing') {
    return <LandingPage onShowLogin={() => setView('auth')} />;
  }

  if (view === 'auth') {
    return (
      <AuthPage
        onSignedIn={(nextSession) => {
          setSession(nextSession);
          setView('dashboard');
        }}
      />
    );
  }

  if (!session) {
    return <LandingPage onShowLogin={() => setView('auth')} />;
  }

  return <DashboardPage session={session} onSignedOut={() => { setSession(null); setView('landing'); }} />;
}

export default App;
