import { Router } from 'express';
import { requireAuth } from '../middleware/auth.js';
import { query } from '../db.js';

const router = Router();
router.use(requireAuth);

router.get('/', async (req, res) => {
  const organizationId = req.user!.organizationId;

  const [fleetCounts] = await query<{
    total_aircraft: number;
    in_service: number;
    maintenance: number;
    aog: number;
  }>(
    `SELECT
      COUNT(*)::int AS total_aircraft,
      COUNT(*) FILTER (WHERE status = 'in_service')::int AS in_service,
      COUNT(*) FILTER (WHERE status = 'maintenance')::int AS maintenance,
      COUNT(*) FILTER (WHERE status = 'aog')::int AS aog
     FROM aircraft WHERE organization_id = $1`,
    [organizationId],
  );

  const [opsCounts] = await query<{
    open_work_orders: number;
    open_squawks: number;
    overdue_inspections: number;
    due_soon_inspections: number;
  }>(
    `SELECT
      (SELECT COUNT(*)::int FROM work_orders WHERE organization_id = $1 AND status <> 'completed') AS open_work_orders,
      (SELECT COUNT(*)::int FROM squawks WHERE organization_id = $1 AND status <> 'closed') AS open_squawks,
      (SELECT COUNT(*)::int FROM inspections WHERE organization_id = $1 AND status = 'overdue') AS overdue_inspections,
      (SELECT COUNT(*)::int FROM inspections WHERE organization_id = $1 AND status = 'due_soon') AS due_soon_inspections`,
    [organizationId],
  );

  const recentAircraft = await query(
    `SELECT id, tail_number, manufacturer, model, status, total_hours, location
     FROM aircraft WHERE organization_id = $1
     ORDER BY created_at DESC
     LIMIT 5`,
    [organizationId],
  );

  const recentWorkOrders = await query(
    `SELECT w.id, w.wo_number, a.tail_number, w.title, w.priority, w.status, w.created_at
     FROM work_orders w
     JOIN aircraft a ON a.id = w.aircraft_id
     WHERE w.organization_id = $1
     ORDER BY w.created_at DESC
     LIMIT 5`,
    [organizationId],
  );

  const recentAudit = await query(
    `SELECT action, entity_type, metadata, created_at
     FROM audit_logs WHERE organization_id = $1
     ORDER BY created_at DESC
     LIMIT 8`,
    [organizationId],
  );

  res.json({ fleetCounts, opsCounts, recentAircraft, recentWorkOrders, recentAudit });
});

export default router;
