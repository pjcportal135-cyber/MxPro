import { Router } from 'express';
import { z } from 'zod';
import { query } from '../db.js';
import { requireAuth, requireRole } from '../middleware/auth.js';

const router = Router();

const aircraftSchema = z.object({
  tailNumber: z.string().min(2).max(20),
  serialNumber: z.string().max(60).optional().or(z.literal('')),
  manufacturer: z.string().min(2).max(60),
  model: z.string().min(1).max(60),
  status: z.enum(['in_service', 'maintenance', 'aog']),
  totalHours: z.coerce.number().min(0),
  totalCycles: z.coerce.number().int().min(0),
  landings: z.coerce.number().int().min(0),
  location: z.string().max(120).optional().or(z.literal('')),
  notes: z.string().optional().or(z.literal('')),
});

router.use(requireAuth);

router.get('/', async (req, res) => {
  const rows = await query(
    `SELECT id, tail_number, serial_number, manufacturer, model, status, total_hours, total_cycles, landings, location, notes, created_at
     FROM aircraft
     WHERE organization_id = $1
     ORDER BY tail_number ASC`,
    [req.user!.organizationId],
  );
  res.json(rows);
});

router.post('/', requireRole(['company_admin', 'maintenance_manager']), async (req, res) => {
  const parsed = aircraftSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ message: 'Invalid body', issues: parsed.error.flatten() });
  }

  const data = parsed.data;

  try {
    const rows = await query(
      `INSERT INTO aircraft (
        organization_id, tail_number, serial_number, manufacturer, model, status,
        total_hours, total_cycles, landings, location, notes
      ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)
      RETURNING id, tail_number, serial_number, manufacturer, model, status, total_hours, total_cycles, landings, location, notes, created_at`,
      [
        req.user!.organizationId,
        data.tailNumber.toUpperCase(),
        data.serialNumber || null,
        data.manufacturer,
        data.model,
        data.status,
        data.totalHours,
        data.totalCycles,
        data.landings,
        data.location || null,
        data.notes || null,
      ],
    );

    await query(
      `INSERT INTO audit_logs (organization_id, actor_user_id, entity_type, entity_id, action, metadata)
       VALUES ($1, $2, 'aircraft', $3, 'created', $4)`,
      [req.user!.organizationId, req.user!.sub, rows[0].id, JSON.stringify({ tailNumber: rows[0].tail_number })],
    );

    res.status(201).json(rows[0]);
  } catch (error: any) {
    if (error?.code === '23505') {
      return res.status(409).json({ message: 'Tail number already exists for this organization' });
    }
    console.error(error);
    res.status(500).json({ message: 'Failed to create aircraft' });
  }
});

export default router;
