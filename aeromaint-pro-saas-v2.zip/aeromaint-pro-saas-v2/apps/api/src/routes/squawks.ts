import { Router } from 'express';
import { z } from 'zod';
import { query } from '../db.js';
import { requireAuth, requireRole } from '../middleware/auth.js';

const router = Router();
router.use(requireAuth);

const squawkSchema = z.object({
  aircraftId: z.string().uuid(),
  reportedBy: z.string().max(120).optional().or(z.literal('')),
  title: z.string().min(2).max(160),
  description: z.string().optional().or(z.literal('')),
  priority: z.enum(['routine', 'priority', 'aog']).default('routine'),
  status: z.enum(['open', 'in_progress', 'deferred', 'closed']).default('open'),
});

router.get('/', async (req, res) => {
  const rows = await query(
    `SELECT s.id, s.aircraft_id, a.tail_number, s.reported_by, s.title, s.description, s.priority, s.status, s.created_at
     FROM squawks s
     JOIN aircraft a ON a.id = s.aircraft_id
     WHERE s.organization_id = $1
     ORDER BY s.created_at DESC`,
    [req.user!.organizationId],
  );
  res.json(rows);
});

router.post('/', requireRole(['company_admin', 'maintenance_manager', 'technician']), async (req, res) => {
  const parsed = squawkSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ message: 'Invalid body', issues: parsed.error.flatten() });
  }

  const data = parsed.data;
  const rows = await query(
    `INSERT INTO squawks (organization_id, aircraft_id, reported_by, title, description, priority, status)
     VALUES ($1,$2,$3,$4,$5,$6,$7)
     RETURNING *`,
    [
      req.user!.organizationId,
      data.aircraftId,
      data.reportedBy || null,
      data.title,
      data.description || null,
      data.priority,
      data.status,
    ],
  );

  await query(
    `INSERT INTO audit_logs (organization_id, actor_user_id, entity_type, entity_id, action, metadata)
     VALUES ($1, $2, 'squawk', $3, 'created', $4)`,
    [req.user!.organizationId, req.user!.sub, rows[0].id, JSON.stringify({ title: rows[0].title, priority: rows[0].priority })],
  );

  res.status(201).json(rows[0]);
});

router.post('/:id/create-work-order', requireRole(['company_admin', 'maintenance_manager']), async (req, res) => {
  const squawks = await query<{ id: string; aircraft_id: string; title: string; description: string | null; priority: string }>(
    `SELECT id, aircraft_id, title, description, priority
     FROM squawks
     WHERE id = $1 AND organization_id = $2`,
    [req.params.id, req.user!.organizationId],
  );

  const squawk = squawks[0];
  if (!squawk) {
    return res.status(404).json({ message: 'Squawk not found' });
  }

  const latest = await query<{ latest_number: string | null }>(
    `SELECT wo_number AS latest_number
     FROM work_orders
     WHERE organization_id = $1
     ORDER BY created_at DESC
     LIMIT 1`,
    [req.user!.organizationId],
  );

  const latestNumber = latest[0]?.latest_number ?? 'WO-0000';
  const seq = Number(String(latestNumber).split('-')[1] || 0) + 1;
  const woNumber = `WO-${String(seq).padStart(4, '0')}`;

  const rows = await query(
    `INSERT INTO work_orders (organization_id, aircraft_id, squawk_id, wo_number, title, description, priority, status)
     VALUES ($1,$2,$3,$4,$5,$6,$7,'open')
     RETURNING *`,
    [req.user!.organizationId, squawk.aircraft_id, squawk.id, woNumber, squawk.title, squawk.description, squawk.priority],
  );

  await query(`UPDATE squawks SET status = 'in_progress', updated_at = NOW() WHERE id = $1`, [squawk.id]);
  await query(
    `INSERT INTO audit_logs (organization_id, actor_user_id, entity_type, entity_id, action, metadata)
     VALUES ($1, $2, 'work_order', $3, 'created_from_squawk', $4)`,
    [req.user!.organizationId, req.user!.sub, rows[0].id, JSON.stringify({ squawkId: squawk.id, woNumber })],
  );

  res.status(201).json(rows[0]);
});

export default router;
