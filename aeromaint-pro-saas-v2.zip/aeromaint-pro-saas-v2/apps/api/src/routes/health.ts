import { Router } from 'express';
import { query } from '../db.js';

const router = Router();

router.get('/', async (_req, res) => {
  try {
    const rows = await query<{ now: string }>('SELECT NOW()::text AS now');
    res.json({ ok: true, dbTime: rows[0]?.now ?? null });
  } catch {
    res.status(500).json({ ok: false });
  }
});

export default router;
