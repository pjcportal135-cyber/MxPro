import { Router } from 'express';
import { z } from 'zod';
import { query } from '../db.js';
import { requireAuth, requireRole } from '../middleware/auth.js';

const router = Router();
router.use(requireAuth);

const workOrderSchema = z.object({
  aircraftId: z.string().uuid(),
  title: z.string().min(2).max(160),
  description: z.string().optional().or(z.literal('')),
  priority: z.enum(['routine', 'priority', 'aog']).default('routine'),
  status: z.enum(['open', 'in_progress', 'awaiting_parts', 'completed']).default('open'),
  assignedTo: z.string().max(120).optional().or(z.literal('')),
  dueOn: z.string().optional().or(z.literal('')),
});

router.get('/', async (req, res) => {
  const rows = await query(
    `SELECT w.id, w.aircraft_id, a.tail_number, w.squawk_id, w.wo_number, w.title, w.description,
            w.priority, w.status, w.assigned_to, w.due_on, w.created_at
     FROM work_orders w
     JOIN aircraft a ON a.id = w.aircraft_id
     WHERE w.organization_id = $1
     ORDER BY w.created_at DESC`,
    [req.user!.organizationId],
  );
  res.json(rows);
});

router.post('/', requireRole(['company_admin', 'maintenance_manager']), async (req, res) => {
  const parsed = workOrderSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ message: 'Invalid body', issues: parsed.error.flatten() });
  }

  const data = parsed.data;
  const latest = await query<{ latest_number: string | null }>(
    `SELECT wo_number AS latest_number FROM work_orders WHERE organization_id = $1 ORDER BY created_at DESC LIMIT 1`,
    [req.user!.organizationId],
  );

  const latestNumber = latest[0]?.latest_number ?? 'WO-0000';
  const seq = Number(String(latestNumber).split('-')[1] || 0) + 1;
  const woNumber = `WO-${String(seq).padStart(4, '0')}`;

  const rows = await query(
    `INSERT INTO work_orders (organization_id, aircraft_id, wo_number, title, description, priority, status, assigned_to, due_on)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
     RETURNING *`,
    [
      req.user!.organizationId,
      data.aircraftId,
      woNumber,
      data.title,
      data.description || null,
      data.priority,
      data.status,
      data.assignedTo || null,
      data.dueOn || null,
    ],
  );

  await query(
    `INSERT INTO audit_logs (organization_id, actor_user_id, entity_type, entity_id, action, metadata)
     VALUES ($1, $2, 'work_order', $3, 'created', $4)`,
    [req.user!.organizationId, req.user!.sub, rows[0].id, JSON.stringify({ woNumber, title: rows[0].title })],
  );

  res.status(201).json(rows[0]);
});

export default router;
