import { Router } from 'express';
import { z } from 'zod';
import { query } from '../db.js';
import { requireAuth, requireRole } from '../middleware/auth.js';

const router = Router();
router.use(requireAuth);

const inspectionSchema = z.object({
  aircraftId: z.string().uuid(),
  code: z.string().min(1).max(40),
  title: z.string().min(2).max(160),
  intervalType: z.enum(['calendar', 'hours', 'cycles']),
  intervalValue: z.coerce.number().int().positive(),
  lastCompletedOn: z.string().optional().or(z.literal('')),
  dueOn: z.string().optional().or(z.literal('')),
  dueHours: z.coerce.number().optional(),
  dueCycles: z.coerce.number().int().optional(),
  status: z.enum(['upcoming', 'due_soon', 'overdue', 'completed']).default('upcoming'),
  notes: z.string().optional().or(z.literal('')),
});

router.get('/', async (req, res) => {
  const rows = await query(
    `SELECT i.id, i.aircraft_id, a.tail_number, i.code, i.title, i.interval_type, i.interval_value,
            i.last_completed_on, i.due_on, i.due_hours, i.due_cycles, i.status, i.notes, i.created_at
     FROM inspections i
     JOIN aircraft a ON a.id = i.aircraft_id
     WHERE i.organization_id = $1
     ORDER BY i.created_at DESC`,
    [req.user!.organizationId],
  );
  res.json(rows);
});

router.post('/', requireRole(['company_admin', 'maintenance_manager']), async (req, res) => {
  const parsed = inspectionSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ message: 'Invalid body', issues: parsed.error.flatten() });
  }

  const data = parsed.data;
  const rows = await query(
    `INSERT INTO inspections (
      organization_id, aircraft_id, code, title, interval_type, interval_value,
      last_completed_on, due_on, due_hours, due_cycles, status, notes
    ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)
    RETURNING *`,
    [
      req.user!.organizationId,
      data.aircraftId,
      data.code.toUpperCase(),
      data.title,
      data.intervalType,
      data.intervalValue,
      data.lastCompletedOn || null,
      data.dueOn || null,
      data.dueHours ?? null,
      data.dueCycles ?? null,
      data.status,
      data.notes || null,
    ],
  );

  await query(
    `INSERT INTO audit_logs (organization_id, actor_user_id, entity_type, entity_id, action, metadata)
     VALUES ($1, $2, 'inspection', $3, 'created', $4)`,
    [req.user!.organizationId, req.user!.sub, rows[0].id, JSON.stringify({ code: rows[0].code, title: rows[0].title })],
  );

  res.status(201).json(rows[0]);
});

export default router;
