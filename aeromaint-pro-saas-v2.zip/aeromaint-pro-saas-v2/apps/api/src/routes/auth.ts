import { Router } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { z } from 'zod';
import { query, pool } from '../db.js';
import { requireAuth } from '../middleware/auth.js';

const router = Router();

const registerSchema = z.object({
  organizationName: z.string().min(2),
  fullName: z.string().min(2),
  email: z.string().email(),
  password: z.string().min(8),
});

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8),
});

function slugify(value: string) {
  return value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 60);
}

router.post('/register', async (req, res) => {
  const parsed = registerSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ message: 'Invalid body', issues: parsed.error.flatten() });
  }

  const { organizationName, fullName, email, password } = parsed.data;
  const client = await pool.connect();

  try {
    await client.query('BEGIN');
    const existingUser = await client.query('SELECT id FROM users WHERE email = $1', [email.toLowerCase()]);
    if (existingUser.rowCount) {
      await client.query('ROLLBACK');
      return res.status(409).json({ message: 'Email already exists' });
    }

    const baseSlug = slugify(organizationName);
    let slug = baseSlug;
    let counter = 1;
    while (true) {
      const existingOrg = await client.query('SELECT id FROM organizations WHERE slug = $1', [slug]);
      if (!existingOrg.rowCount) break;
      counter += 1;
      slug = `${baseSlug}-${counter}`;
    }

    const orgResult = await client.query(
      'INSERT INTO organizations (name, slug) VALUES ($1, $2) RETURNING id, name, slug, plan',
      [organizationName, slug],
    );
    const organization = orgResult.rows[0];

    const passwordHash = await bcrypt.hash(password, 10);
    const userResult = await client.query(
      'INSERT INTO users (full_name, email, password_hash) VALUES ($1, $2, $3) RETURNING id, full_name, email',
      [fullName, email.toLowerCase(), passwordHash],
    );
    const user = userResult.rows[0];

    const membershipResult = await client.query(
      'INSERT INTO memberships (organization_id, user_id, role) VALUES ($1, $2, $3) RETURNING role',
      [organization.id, user.id, 'company_admin'],
    );
    const membership = membershipResult.rows[0];

    await client.query(
      'INSERT INTO audit_logs (organization_id, actor_user_id, entity_type, entity_id, action, metadata) VALUES ($1, $2, $3, $4, $5, $6)',
      [organization.id, user.id, 'organization', organization.id, 'created', JSON.stringify({ name: organization.name })],
    );

    await client.query('COMMIT');

    const secret = process.env.JWT_SECRET;
    if (!secret) return res.status(500).json({ message: 'Missing JWT secret' });

    const token = jwt.sign(
      {
        sub: user.id,
        organizationId: organization.id,
        membershipRole: membership.role,
        email: user.email,
      },
      secret,
      { expiresIn: '7d' },
    );

    res.status(201).json({
      token,
      user: {
        id: user.id,
        fullName: user.full_name,
        email: user.email,
        role: membership.role,
      },
      organization,
    });
  } catch (error) {
    await client.query('ROLLBACK');
    console.error(error);
    res.status(500).json({ message: 'Failed to register' });
  } finally {
    client.release();
  }
});

router.post('/login', async (req, res) => {
  const parsed = loginSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ message: 'Invalid body', issues: parsed.error.flatten() });
  }

  const { email, password } = parsed.data;
  const rows = await query<{
    user_id: string;
    full_name: string;
    email: string;
    password_hash: string;
    organization_id: string;
    organization_name: string;
    organization_slug: string;
    plan: string;
    role: string;
  }>(
    `SELECT
      u.id AS user_id,
      u.full_name,
      u.email,
      u.password_hash,
      o.id AS organization_id,
      o.name AS organization_name,
      o.slug AS organization_slug,
      o.plan,
      m.role
     FROM users u
     JOIN memberships m ON m.user_id = u.id
     JOIN organizations o ON o.id = m.organization_id
     WHERE u.email = $1 AND u.is_active = TRUE AND o.is_active = TRUE
     ORDER BY o.created_at ASC
     LIMIT 1`,
    [email.toLowerCase()],
  );

  const record = rows[0];
  if (!record) {
    return res.status(401).json({ message: 'Invalid credentials' });
  }

  const passwordMatches = await bcrypt.compare(password, record.password_hash);
  if (!passwordMatches) {
    return res.status(401).json({ message: 'Invalid credentials' });
  }

  const secret = process.env.JWT_SECRET;
  if (!secret) return res.status(500).json({ message: 'Missing JWT secret' });

  const token = jwt.sign(
    {
      sub: record.user_id,
      organizationId: record.organization_id,
      membershipRole: record.role,
      email: record.email,
    },
    secret,
    { expiresIn: '7d' },
  );

  res.json({
    token,
    user: {
      id: record.user_id,
      fullName: record.full_name,
      email: record.email,
      role: record.role,
    },
    organization: {
      id: record.organization_id,
      name: record.organization_name,
      slug: record.organization_slug,
      plan: record.plan,
    },
  });
});

router.get('/me', requireAuth, async (req, res) => {
  const user = req.user;
  if (!user) return res.status(401).json({ message: 'Unauthorized' });

  const rows = await query<{
    full_name: string;
    org_name: string;
    org_slug: string;
    plan: string;
  }>(
    `SELECT u.full_name, o.name AS org_name, o.slug AS org_slug, o.plan
     FROM users u
     JOIN organizations o ON o.id = $1
     WHERE u.id = $2`,
    [user.organizationId, user.sub],
  );

  const profile = rows[0];
  res.json({
    user: {
      id: user.sub,
      email: user.email,
      fullName: profile?.full_name ?? '',
      role: user.membershipRole,
    },
    organization: {
      id: user.organizationId,
      name: profile?.org_name ?? '',
      slug: profile?.org_slug ?? '',
      plan: profile?.plan ?? 'trial',
    },
  });
});

export default router;
