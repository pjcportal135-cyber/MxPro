import 'dotenv/config';
import bcrypt from 'bcryptjs';
import { pool } from '../db.js';

async function run() {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    const orgResult = await client.query(
      `INSERT INTO organizations (name, slug, plan)
       VALUES ('SkyBridge Aviation', 'skybridge-aviation', 'trial')
       ON CONFLICT (slug) DO UPDATE SET name = EXCLUDED.name
       RETURNING id`,
    );
    const organizationId = orgResult.rows[0].id;

    const passwordHash = await bcrypt.hash('ChangeMe123!', 10);
    const userResult = await client.query(
      `INSERT INTO users (full_name, email, password_hash)
       VALUES ('Jose Admin', 'admin@skybridge.aero', $1)
       ON CONFLICT (email) DO UPDATE SET full_name = EXCLUDED.full_name
       RETURNING id`,
      [passwordHash],
    );
    const userId = userResult.rows[0].id;

    await client.query(
      `INSERT INTO memberships (organization_id, user_id, role)
       VALUES ($1, $2, 'company_admin')
       ON CONFLICT (organization_id, user_id) DO NOTHING`,
      [organizationId, userId],
    );

    const aircraftRows = [] as { id: string; tail: string }[];
    const aircraft = [
      ['N651CV', '560-0451', 'Cessna', 'Citation VII', 'in_service', 8186.4, 6131, 6131, 'KOPF'],
      ['N18141', '33821', 'Boeing', '737-800', 'maintenance', 24110.2, 18550, 18492, 'KMIA'],
      ['N22QX', '11234', 'Airbus', 'A320neo', 'aog', 9310.5, 6401, 6395, 'SKBO'],
    ];

    for (const item of aircraft) {
      const result = await client.query(
        `INSERT INTO aircraft (
          organization_id, tail_number, serial_number, manufacturer, model, status,
          total_hours, total_cycles, landings, location
        ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
        ON CONFLICT (organization_id, tail_number)
        DO UPDATE SET model = EXCLUDED.model
        RETURNING id, tail_number`,
        [organizationId, ...item],
      );
      aircraftRows.push({ id: result.rows[0].id, tail: result.rows[0].tail_number });
    }

    const [citation, boeing, airbus] = aircraftRows;

    await client.query(`DELETE FROM inspections WHERE organization_id = $1`, [organizationId]);
    await client.query(`DELETE FROM squawks WHERE organization_id = $1`, [organizationId]);
    await client.query(`DELETE FROM work_orders WHERE organization_id = $1`, [organizationId]);

    await client.query(
      `INSERT INTO inspections (organization_id, aircraft_id, code, title, interval_type, interval_value, last_completed_on, due_on, status, notes)
       VALUES
       ($1,$2,'INSP-36M','36 month structural inspection','calendar',36,'2022-12-08','2025-12-31','overdue','Inspection package needs planning'),
       ($1,$3,'ENG-500H','Engine borescope','hours',500,NULL, NULL, 'due_soon', 'Due at 24500 aircraft hours'),
       ($1,$4,'A320-CAB','Cabin safety inspection','calendar',12,'2025-08-01','2026-08-01','upcoming','Annual cabin condition review')`,
      [organizationId, citation.id, boeing.id, airbus.id],
    );

    const squawkResult = await client.query(
      `INSERT INTO squawks (organization_id, aircraft_id, reported_by, title, description, priority, status)
       VALUES
       ($1,$2,'Capt. Rivera','Left landing light inoperative','Reported during post-flight walkaround','priority','open'),
       ($1,$3,'Line MX','Hydraulic seep on gear door actuator','Needs troubleshooting before next dispatch','aog','in_progress')
       RETURNING id, aircraft_id, title, description, priority`,
      [organizationId, citation.id, airbus.id],
    );

    const firstSquawk = squawkResult.rows[0];
    await client.query(
      `INSERT INTO work_orders (organization_id, aircraft_id, squawk_id, wo_number, title, description, priority, status, assigned_to, due_on)
       VALUES
       ($1,$2,$3,'WO-0001','Resolve landing light discrepancy','Replace bulb and operational check','priority','open','A. Gomez','2026-03-18'),
       ($1,$4,NULL,'WO-0002','A-check prep package','Open cards and verify materials','routine','in_progress','M. Torres','2026-03-25')`,
      [organizationId, citation.id, firstSquawk.id, airbus.id],
    );

    await client.query(
      `INSERT INTO audit_logs (organization_id, actor_user_id, entity_type, action, metadata)
       VALUES
       ($1, $2, 'seed', 'seeded_demo', $3),
       ($1, $2, 'inspection', 'seeded', $4),
       ($1, $2, 'work_order', 'seeded', $5)`,
      [
        organizationId,
        userId,
        JSON.stringify({ seeded: true }),
        JSON.stringify({ count: 3 }),
        JSON.stringify({ count: 2 }),
      ],
    );

    await client.query('COMMIT');
    console.log('Seed complete. Demo login: admin@skybridge.aero / ChangeMe123!');
  } catch (error) {
    await client.query('ROLLBACK');
    console.error(error);
    process.exitCode = 1;
  } finally {
    client.release();
    await pool.end();
  }
}

run();
