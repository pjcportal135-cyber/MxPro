import 'dotenv/config';
import cors from 'cors';
import express from 'express';
import healthRoutes from './routes/health.js';
import authRoutes from './routes/auth.js';
import dashboardRoutes from './routes/dashboard.js';
import aircraftRoutes from './routes/aircraft.js';
import inspectionsRoutes from './routes/inspections.js';
import squawksRoutes from './routes/squawks.js';
import workOrdersRoutes from './routes/work-orders.js';

const app = express();
const port = Number(process.env.PORT || 4000);

app.use(
  cors({
    origin: process.env.CLIENT_ORIGIN?.split(',') ?? ['http://localhost:5173'],
    credentials: false,
  }),
);
app.use(express.json());

app.get('/', (_req, res) => {
  res.json({ name: 'AeroMaint Pro SaaS API', version: '2.1.0' });
});

app.use('/api/health', healthRoutes);
app.use('/api/auth', authRoutes);
app.use('/api/dashboard', dashboardRoutes);
app.use('/api/aircraft', aircraftRoutes);
app.use('/api/inspections', inspectionsRoutes);
app.use('/api/squawks', squawksRoutes);
app.use('/api/work-orders', workOrdersRoutes);

app.listen(port, () => {
  console.log(`API running on http://localhost:${port}`);
});
