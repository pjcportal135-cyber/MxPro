export type AppRole = 'company_admin' | 'maintenance_manager' | 'technician' | 'inspector';

export interface AuthTokenPayload {
  sub: string;
  organizationId: string;
  membershipRole: AppRole;
  email: string;
}

export interface RequestUser extends AuthTokenPayload {
  name?: string;
}
